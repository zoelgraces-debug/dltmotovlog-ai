# DLT Motovlog AI Image Generator

Aplikasi web generator Text-to-Image menggunakan OpenAI DALL·E via Netlify Functions.

## Deploy ke Netlify

1. Fork/Upload repo ini ke GitHub.
2. Hubungkan ke Netlify (Import from Git).
3. Tambahkan Environment Variable di Netlify:
   - OPENAI_API_KEY = (API Key OpenAI Anda)
4. Deploy site.

## Embed ke Blogspot

Gunakan iframe:
```html
<iframe src="https://YOUR-SITE.netlify.app"
        width="100%" height="800"
        style="border:none; border-radius:12px;">
</iframe>
```
