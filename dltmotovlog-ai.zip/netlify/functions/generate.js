// netlify/functions/generate.js
export async function handler(event) {
  try {
    if (event.httpMethod !== 'POST') {
      return { statusCode: 405, body: 'Method Not Allowed' };
    }
    const body = JSON.parse(event.body || '{}');
    const { prompt, width = 512, height = 512, init_image } = body;

    if (!prompt) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Prompt required' }) };
    }

    const OPENAI_KEY = process.env.OPENAI_API_KEY;
    const sizeStr = `${width}x${height}`;

    // Text to image
    const payload = { model: 'gpt-image-1', prompt, size: sizeStr, response_format: 'b64_json' };
    const res = await fetch('https://api.openai.com/v1/images/generations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${OPENAI_KEY}` },
      body: JSON.stringify(payload)
    });
    const json = await res.json();
    const images = (json.data || []).map(i => i.b64_json).filter(Boolean);

    return { statusCode: 200, headers: { 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ images }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
}
